<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CategorySelect - Price Rule</name>
   <tag></tag>
   <elementGuidId>d8366b1f-d904-476b-acb1-0311b176d30e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//select[@id=&quot;carSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//select[@id=&quot;carSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
   </webElementProperties>
</WebElementEntity>
