<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DurationDropDown - Price Rule</name>
   <tag></tag>
   <elementGuidId>e5fdf2bf-e8f5-4dc0-89ce-ec38f035204a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/button</value>
   </webElementProperties>
</WebElementEntity>
