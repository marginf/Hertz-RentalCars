<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Season - Select All</name>
   <tag></tag>
   <elementGuidId>acd63306-9a70-42a5-b5f8-09564c6c0aa3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//select[@id=&quot;seasonSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//select[@id=&quot;seasonSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
   </webElementProperties>
</WebElementEntity>
