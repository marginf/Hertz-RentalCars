<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Group - Select All</name>
   <tag></tag>
   <elementGuidId>d8411ce9-0719-426b-b072-fe691d89a1f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;seasonGroupSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;seasonGroupSelect&quot;]/../div//input[@value=&quot;multiselect-all&quot;]</value>
   </webElementProperties>
</WebElementEntity>
