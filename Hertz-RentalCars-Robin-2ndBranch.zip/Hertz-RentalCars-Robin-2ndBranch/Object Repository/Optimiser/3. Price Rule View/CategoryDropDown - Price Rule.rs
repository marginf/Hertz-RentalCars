<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CategoryDropDown - Price Rule</name>
   <tag></tag>
   <elementGuidId>1dc6ebf1-14cd-4fa5-870b-4b65ec294db8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//select[@id=&quot;carSelect&quot;]/../div//button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//select[@id=&quot;carSelect&quot;]/../div//button</value>
   </webElementProperties>
</WebElementEntity>
