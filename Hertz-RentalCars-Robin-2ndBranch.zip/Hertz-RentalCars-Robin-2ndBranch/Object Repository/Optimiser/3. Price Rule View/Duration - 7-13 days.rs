<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Duration - 7-13 days</name>
   <tag></tag>
   <elementGuidId>789fcb7f-38e5-4447-836c-bf23894d4130</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/ul/li[7]/a/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/ul/li[7]/a/label/span</value>
   </webElementProperties>
</WebElementEntity>
