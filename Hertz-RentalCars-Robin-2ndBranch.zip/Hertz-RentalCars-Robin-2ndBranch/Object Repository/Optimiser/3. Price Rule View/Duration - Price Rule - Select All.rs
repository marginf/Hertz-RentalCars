<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Duration - Price Rule - Select All</name>
   <tag></tag>
   <elementGuidId>eb004824-a949-4391-8970-2c1cc9b65ce3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/ul/li[1]/a/label/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[3]/div[1]/div/fieldset/div[3]/div[4]/div/div/div/ul/li[1]/a/label/input</value>
   </webElementProperties>
</WebElementEntity>
