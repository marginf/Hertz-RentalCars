<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Data_Table - InsertCell1</name>
   <tag></tag>
   <elementGuidId>533049ba-389c-4f56-bd99-8689cb355fa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;displayTable&quot;]/tbody/tr[3]/td[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;displayTable&quot;]/tbody/tr[3]/td[2]/input</value>
   </webElementProperties>
</WebElementEntity>
