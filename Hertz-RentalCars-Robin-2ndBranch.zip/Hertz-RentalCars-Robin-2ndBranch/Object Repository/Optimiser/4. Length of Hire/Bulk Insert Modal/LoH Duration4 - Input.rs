<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoH Duration4 - Input</name>
   <tag></tag>
   <elementGuidId>3df3ff54-b47a-4038-ba25-1268bdec67aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[4]/th[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[4]/th[2]/input</value>
   </webElementProperties>
</WebElementEntity>
