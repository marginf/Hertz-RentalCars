<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Season Group-Option</name>
   <tag></tag>
   <elementGuidId>30daf229-f971-4f35-89d9-b13fc8ef5e3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/button</value>
   </webElementProperties>
</WebElementEntity>
