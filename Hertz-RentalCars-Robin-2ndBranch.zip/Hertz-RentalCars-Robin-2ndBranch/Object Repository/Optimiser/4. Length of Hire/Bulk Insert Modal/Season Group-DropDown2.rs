<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Season Group-DropDown2</name>
   <tag></tag>
   <elementGuidId>0c1b2d86-c734-4244-93f7-b985a8379ce1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[4]/a/label/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[4]/a/label/input</value>
   </webElementProperties>
</WebElementEntity>
