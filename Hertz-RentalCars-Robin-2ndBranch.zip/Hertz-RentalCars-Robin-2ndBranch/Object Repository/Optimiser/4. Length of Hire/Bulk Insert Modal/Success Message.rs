<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Success Message</name>
   <tag></tag>
   <elementGuidId>7a1a8ab8-1b80-4fe2-bc74-8dc5a544b178</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;collapseExample&quot;]/div/div[5]/div[2]/div/div[2]/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;collapseExample&quot;]/div/div[5]/div[2]/div/div[2]/div/span</value>
   </webElementProperties>
</WebElementEntity>
