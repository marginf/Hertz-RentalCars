<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoH Duration2 - Input</name>
   <tag></tag>
   <elementGuidId>6702d771-bb77-4277-92b3-89179a9633f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[2]/th[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[2]/th[2]/input</value>
   </webElementProperties>
</WebElementEntity>
