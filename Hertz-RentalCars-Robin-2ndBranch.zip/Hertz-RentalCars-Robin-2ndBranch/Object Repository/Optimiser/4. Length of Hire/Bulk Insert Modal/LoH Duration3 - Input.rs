<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoH Duration3 - Input</name>
   <tag></tag>
   <elementGuidId>af309375-8de5-4085-973a-f87cceb47cc2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[3]/th[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[3]/th[2]/input</value>
   </webElementProperties>
</WebElementEntity>
