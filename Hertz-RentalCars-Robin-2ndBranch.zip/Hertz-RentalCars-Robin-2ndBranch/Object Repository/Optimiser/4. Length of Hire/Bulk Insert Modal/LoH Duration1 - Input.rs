<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoH Duration1 - Input</name>
   <tag></tag>
   <elementGuidId>b859ceba-fde7-4fc2-815f-fd524e82bc45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[1]/th[2]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[1]/th[2]/input</value>
   </webElementProperties>
</WebElementEntity>
