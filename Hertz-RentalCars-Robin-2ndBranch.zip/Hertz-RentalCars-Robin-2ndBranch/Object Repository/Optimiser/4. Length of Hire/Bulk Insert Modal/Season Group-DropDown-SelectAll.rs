<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Season Group-DropDown-SelectAll</name>
   <tag></tag>
   <elementGuidId>71e3c608-01e9-464f-be27-db314f90d863</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[1]/a/label/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[1]/a/label/input</value>
   </webElementProperties>
</WebElementEntity>
