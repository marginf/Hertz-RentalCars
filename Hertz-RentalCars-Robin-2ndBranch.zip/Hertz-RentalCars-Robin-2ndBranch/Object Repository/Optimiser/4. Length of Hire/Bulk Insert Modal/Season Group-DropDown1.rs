<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Season Group-DropDown1</name>
   <tag></tag>
   <elementGuidId>6ab3dd76-815e-4d69-acda-3173b9e3b82c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[2]/a/label/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;collapseExample&quot;]/div/div[1]/div[2]/div/div/ul/li[2]/a/label/input</value>
   </webElementProperties>
</WebElementEntity>
