<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoH Duration7</name>
   <tag></tag>
   <elementGuidId>b37250d6-92d4-4dac-9013-54ce646f7ecf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[7]/th[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;applyTable&quot;]/tbody/tr[7]/th[2]</value>
   </webElementProperties>
</WebElementEntity>
