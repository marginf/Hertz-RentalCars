<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Data_Table - ClickCell1</name>
   <tag></tag>
   <elementGuidId>5c5ab34f-ada2-4d03-9770-d9532c11f5f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;displayTable&quot;]/tbody/tr[3]/td[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;displayTable&quot;]/tbody/tr[3]/td[2]</value>
   </webElementProperties>
</WebElementEntity>
