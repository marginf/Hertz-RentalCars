<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Table_PriceCell3 - Input</name>
   <tag></tag>
   <elementGuidId>efa60012-df0d-416e-a8a1-fdeccc9db714</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[3]/td[5]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[3]/td[5]/input</value>
   </webElementProperties>
</WebElementEntity>
