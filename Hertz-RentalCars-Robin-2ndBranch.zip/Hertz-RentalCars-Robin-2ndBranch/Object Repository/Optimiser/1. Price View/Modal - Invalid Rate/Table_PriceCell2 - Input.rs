<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Table_PriceCell2 - Input</name>
   <tag></tag>
   <elementGuidId>8d294d1f-db4b-41e3-b826-18146a880a49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[2]/td[5]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[2]/td[5]/input</value>
   </webElementProperties>
</WebElementEntity>
