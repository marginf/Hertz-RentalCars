<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Table_PriceCell1 - Input</name>
   <tag></tag>
   <elementGuidId>5b321d87-eef9-47de-8f05-cdc06b25cdd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[1]/td[5]/input</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;inVildRatesTable&quot;]/tbody/tr[1]/td[5]/input</value>
   </webElementProperties>
</WebElementEntity>
