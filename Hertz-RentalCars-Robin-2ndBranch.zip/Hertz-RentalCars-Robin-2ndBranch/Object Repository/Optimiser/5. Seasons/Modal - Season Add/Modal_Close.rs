<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Modal_Close</name>
   <tag></tag>
   <elementGuidId>8617d024-d326-4a4c-8e21-af3c04cc5a13</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id=&quot;detailsDialog&quot;]/div/div/div/div/div/div[1]/div/button[count(. | //*[@ref_element = 'Object Repository/Season Add - Modal/Page_Car Rental - Portal/iframe_Regional Season_PageCon']) = count(//*[@ref_element = 'Object Repository/Season Add - Modal/Page_Car Rental - Portal/iframe_Regional Season_PageCon'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;detailsDialog&quot;]/div/div/div/div/div/div[1]/div/button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Season Add - Modal/Page_Car Rental - Portal/iframe_Regional Season_PageCon</value>
   </webElementProperties>
</WebElementEntity>
