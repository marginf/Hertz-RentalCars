import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.chrome.ChromeDriver as ChromeDriver
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.By as By
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import org.apache.commons.lang.time.StopWatch
import com.kms.katalon.core.exception.StepErrorException as StepErrorException
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.testdata.DBData


WebUI.openBrowser('')
WebUI.maximizeWindow()
//WebUI.comment('User logs into MF')
WebUI.navigateToUrl('https://marginfueltest.azurewebsites.net/Home/Login')

WebUI.setText(findTestObject('Global Objects/input_Username'), 'PTHertzrentals')

WebUI.setText(findTestObject('Global Objects/input_Password'), Password)

WebUI.click(findTestObject('Global Objects/button_Login'))

//WebUI.comment('The welcome menu sometimes expands, sometimes not')
//WebUI.click(findTestObject('Global Objects/Page_Car Rental - Portal/span_Welcome_menu-text'))

WebUI.click(findTestObject('Global Objects/span_Optimiser'))

WebUI.click(findTestObject('Global Objects/a_Price Rule View'))

WebUI.switchToFrame(findTestObject('Optimiser/3. Price Rule View/iframe_Price Rule View_PageCon'),1)

//WebUI.comment('Select Market')
//WebUI.focus(findTestObject('Optimiser/3. Price Rule View/select_Market'))
//WebUI.selectOptionByIndex(findTestObject('Optimiser/3. Price Rule View/select_Market'),0)

//WebUI.comment('Select Channel')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/ChannelDropDown'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/ChannelSelect'))
WebUI.click(findTestObject('Optimiser/3. Price Rule View/ChannelDropDown'))

//WebUI.comment('Select Region')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/RegionDropDown'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/RegionSelect'))
WebUI.click(findTestObject('Optimiser/3. Price Rule View/RegionDropDown'))

//WebUI.comment('Select Category')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/CategoryDropDown - Price Rule'))
WebUI.uncheck(findTestObject('Optimiser/3. Price Rule View/CategorySelect - Price Rule'))

//WebUI.comment('Select Car from Category')
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_1 - Price Rule'))
TempCar1 = WebUI.getText(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_1 - Price Rule - Text'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_2 - Price Rule'))
TempCar2 = WebUI.getText(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_2 - Price Rule - Text'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_5 - Price Rule'))
TempCar5 = WebUI.getText(findTestObject('Optimiser/3. Price Rule View/Select_Category_Car_5 - Price Rule - Text'))
WebUI.click(findTestObject('Optimiser/3. Price Rule View/CategoryDropDown - Price Rule'))

//WebUI.comment('Select Group')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/GroupsDropDown'))
WebUI.uncheck(findTestObject('Optimiser/3. Price Rule View/Group - Select All'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Group - Option 2'))

//WebUI.comment('Select Seasons')
WebUI.waitForElementClickable(findTestObject('Optimiser/3. Price Rule View/SeasonSelect'),1)
WebUI.click(findTestObject('Optimiser/3. Price Rule View/SeasonSelect'))
WebUI.uncheck(findTestObject('Optimiser/3. Price Rule View/Season - Select All'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Season - Option 2'))

//WebUI.comment('Set Duration')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/DurationDropDown - Price Rule'))
WebUI.uncheck(findTestObject('Optimiser/3. Price Rule View/Duration - Price Rule - Select All'))
WebUI.check(findTestObject('Optimiser/3. Price Rule View/Duration - 7-13 days'))
//WebUI.click(findTestObject('Optimiser/3. Price Rule View/select_Duration - Price Rule'))

//WebUI.comment('Extract Duration')
//WebUI.click(findTestObject('Optimiser/3. Price Rule View/DurationDropDown - Price Rule'))

try {
//WebUI.comment('Click on Search button')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/button_Search'))

//WebUI.comment('Maximise result display number')
WebUI.click(findTestObject('Optimiser/3. Price Rule View/select_ResultDisplayNumber'))
WebUI.selectOptionByValue(findTestObject('Optimiser/3. Price Rule View/select_ResultDisplayNumber'),'50',false)

WebUI.click(findTestObject('Optimiser/3. Price Rule View/select_ResultDisplayNumber'))
if (WebUI.verifyTextPresent('Please Select',false)) {
	throw new com.kms.katalon.core.exception.StepErrorException('Alert present')
	}
}
catch (StepErrorException e) {
	this.println(e)
}
catch (Exception e) {
	this.println("General issue occurs")
}
finally {
// Start stopwatch
StopWatch stopwatch = new StopWatch()
stopwatch.start()
//'Wait for jQuery to be loaded in 60 seconds timeout.
WebUI.waitForJQueryLoad(60)
stopwatch.stop()
long timeTaken = stopwatch.getTime()  // milli seconds
WebUI.comment(">>> timeTaken = ${timeTaken}")

//Get number of Cars returned from search
Car_No_Text = WebUI.getText(findTestObject('Optimiser/3. Price Rule View/Result_table_info'));
Car_No2R = (Car_No_Text.split('of ')[1])
No_Cars = (Car_No2R.substring(0,2))
println(Car_No2R)
println(No_Cars)
ResultNumber = ('50')
WebUI.verifyEqual(ResultNumber,No_Cars)

// Compare Row Count against SQL query Count
DBData dbTestData = findTestData('Enter name of data file here')
dbTestData.fetchedData = dbTestData.fetchData()
dbCount = dbTestData.getValue(1,1)
WebUI.verifyEqual(dbCount,No_Cars)

//User logs out
WebUI.switchToFrame(findTestObject('Global Objects/iframe_NavigationBar'),2)
//WebUI.click(findTestObject('Global Objects/Page_Car Rental - Portal/Select_span_Welcome'))
WebUI.click(findTestObject('Global Objects/span_Welcome'))
WebUI.delay(2)
WebUI.click(findTestObject('null'))
WebUI.delay(2)

//Log User out
WebUI.switchToDefaultContent()
WebUI.delay(1)
WebUI.click(findTestObject('Global Objects/span_Welcome'))
WebUI.waitForElementVisible(findTestObject('Global Objects/a_Logout'),2)
WebUI.click(findTestObject('Global Objects/a_Logout'))
WebUI.delay(2)
WebUI.closeBrowser()
}